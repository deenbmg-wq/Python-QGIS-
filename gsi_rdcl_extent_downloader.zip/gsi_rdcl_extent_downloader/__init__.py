# -*- coding: utf-8 -*-
def classFactory(iface):
    from .gsi_rdcl_extent_downloader import GsiRdclExtentDownloader
    return GsiRdclExtentDownloader(iface)
