\
# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QObject, pyqtSignal, Qt, QUrl, QVariant
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QProgressDialog
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtNetwork import QNetworkRequest

from qgis.core import (
    QgsProject,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsRectangle,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsJsonUtils,
    QgsBlockingNetworkRequest,
    QgsMessageLog,
    QgsWkbTypes,
    Qgis
)
from qgis.gui import QgsMapTool, QgsRubberBand

import math


import os
# ---- Map tool (drag rectangle) ----
class RectangleExtentTool(QgsMapTool):
    extentCaptured = pyqtSignal(QgsRectangle)

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self._start = None
        self._rubber = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self._rubber.setFillColor(Qt.transparent)
        self._rubber.setWidth(2)

    def canvasPressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        self._start = self.toMapCoordinates(e.pos())
        self._rubber.reset(QgsWkbTypes.PolygonGeometry)

    def canvasMoveEvent(self, e):
        if not self._start:
            return
        end = self.toMapCoordinates(e.pos())
        rect = QgsRectangle(self._start, end)
        self._show_rect(rect)

    def canvasReleaseEvent(self, e):
        if e.button() != Qt.LeftButton or not self._start:
            return
        end = self.toMapCoordinates(e.pos())
        rect = QgsRectangle(self._start, end)
        self._start = None
        self._rubber.reset(QgsWkbTypes.PolygonGeometry)
        if rect.isEmpty() or rect.width() == 0 or rect.height() == 0:
            return
        self.extentCaptured.emit(rect)

    def deactivate(self):
        self._rubber.reset(QgsWkbTypes.PolygonGeometry)
        self._start = None
        super().deactivate()

    def _show_rect(self, rect: QgsRectangle):
        x_min, x_max = rect.xMinimum(), rect.xMaximum()
        y_min, y_max = rect.yMinimum(), rect.yMaximum()

        pts = [
            (x_min, y_min),
            (x_min, y_max),
            (x_max, y_max),
            (x_max, y_min),
            (x_min, y_min),
        ]
        self._rubber.reset(QgsWkbTypes.PolygonGeometry)
        self._rubber.addPointXY(self._mkpt(pts[0]), False)
        for p in pts[1:]:
            self._rubber.addPointXY(self._mkpt(p), False)
        self._rubber.show()

    @staticmethod
    def _mkpt(xy):
        from qgis.core import QgsPointXY
        return QgsPointXY(xy[0], xy[1])


# ---- Tile math (XYZ WebMercator scheme) ----
def _clamp(v, vmin, vmax):
    return max(vmin, min(vmax, v))

def lonlat_to_tile(lon: float, lat: float, z: int):
    # Standard slippy map tile math
    lat = _clamp(lat, -85.05112878, 85.05112878)
    n = 2.0 ** z
    xtile = int((lon + 180.0) / 360.0 * n)
    lat_rad = math.radians(lat)
    ytile = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    xtile = _clamp(xtile, 0, int(n) - 1)
    ytile = _clamp(ytile, 0, int(n) - 1)
    return xtile, ytile

def tiles_for_bbox(min_lon, min_lat, max_lon, max_lat, z: int):
    # y increases southward, so north (max_lat) gives smaller y.
    x_min, y_max = lonlat_to_tile(min_lon, min_lat, z)
    x_max, y_min = lonlat_to_tile(max_lon, max_lat, z)
    if x_min > x_max:
        x_min, x_max = x_max, x_min
    if y_min > y_max:
        y_min, y_max = y_max, y_min
    tiles = []
    for x in range(x_min, x_max + 1):
        for y in range(y_min, y_max + 1):
            tiles.append((x, y))
    return tiles


# ---- Main plugin ----
class GsiRdclExtentDownloader(QObject):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.action = None
        self._prev_tool = None
        self._tool = None

        # Settings
        self.Z = 16
        self.dataset = "experimental_rdcl"
        self.max_tiles = 2000  # safety guard

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon_z16.svg")
        self.action = QAction(QIcon(icon_path), "GSI RDCL (Z16) 範囲指定ダウンロード", self.iface.mainWindow())
        self.action.triggered.connect(self.activate_tool)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&GSI RDCL Downloader", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&GSI RDCL Downloader", self.action)
            self.action = None

    def activate_tool(self):
        canvas = self.iface.mapCanvas()
        self._prev_tool = canvas.mapTool()

        self._tool = RectangleExtentTool(canvas)
        self._tool.extentCaptured.connect(self._on_extent_captured)

        self.iface.messageBar().pushMessage(
            "GSI RDCL Downloader",
            "地図上でドラッグして範囲を指定してください（左クリック）",
            level=Qgis.Info,
            duration=6
        )
        canvas.setMapTool(self._tool)

    def _on_extent_captured(self, rect: QgsRectangle):
        # restore tool early
        canvas = self.iface.mapCanvas()
        if self._prev_tool:
            canvas.setMapTool(self._prev_tool)

        try:
            self.download_and_add_layer(rect)
        except Exception as ex:
            QMessageBox.critical(self.iface.mainWindow(), "GSI RDCL Downloader", f"エラー:\n{ex}")

    def download_and_add_layer(self, rect_map_crs: QgsRectangle):
        project = QgsProject.instance()
        canvas = self.iface.mapCanvas()
        src_crs = canvas.mapSettings().destinationCrs()
        dst_crs = QgsCoordinateReferenceSystem("EPSG:4326")

        xform = QgsCoordinateTransform(src_crs, dst_crs, project)
        rect4326 = xform.transformBoundingBox(rect_map_crs)

        min_lon = rect4326.xMinimum()
        min_lat = rect4326.yMinimum()
        max_lon = rect4326.xMaximum()
        max_lat = rect4326.yMaximum()

        tiles = tiles_for_bbox(min_lon, min_lat, max_lon, max_lat, self.Z)
        if len(tiles) == 0:
            return
        if len(tiles) > self.max_tiles:
            raise RuntimeError(f"選択範囲が広すぎます（Z={self.Z}で {len(tiles)} タイル）。もう少し範囲を小さくしてください。")

        # Prepare memory layer
        layer_name = f"gsi_{self.dataset}_z{self.Z}"
        layer = QgsVectorLayer("LineString?crs=EPSG:4326", layer_name, "memory")
        if not layer.isValid():
            raise RuntimeError("一時レイヤーの作成に失敗しました。")

        dp = layer.dataProvider()
        existing_fields = set()

        progress = QProgressDialog("タイルをダウンロード中…", "キャンセル", 0, len(tiles), self.iface.mainWindow())
        progress.setWindowModality(Qt.ApplicationModal)
        progress.setMinimumDuration(0)

        total_features = 0
        failed = 0

        for i, (x, y) in enumerate(tiles, start=1):
            if progress.wasCanceled():
                break
            progress.setValue(i - 1)
            progress.setLabelText(f"タイル {i}/{len(tiles)} 取得中…  z={self.Z} x={x} y={y}")

            url = f"https://cyberjapandata.gsi.go.jp/xyz/{self.dataset}/{self.Z}/{x}/{y}.geojson"

            json_str = self._fetch_text(url)
            if not json_str:
                failed += 1
                continue

            try:
                tile_fields = QgsJsonUtils.stringToFields(json_str)
                tile_feats = QgsJsonUtils.stringToFeatureList(json_str, tile_fields)
            except Exception as ex:
                QgsMessageLog.logMessage(f"GeoJSON parse failed: {url} ({ex})", "GSI RDCL Downloader", Qgis.Warning)
                failed += 1
                continue

            # Add new fields if needed
            new_fields = []
            for fld in tile_fields:
                name = fld.name()
                if name in existing_fields:
                    continue
                # if field type is invalid, fallback to string
                if fld.type() == QVariant.Invalid:
                    fld = QgsField(name, QVariant.String)
                new_fields.append(fld)
                existing_fields.add(name)
            if new_fields:
                dp.addAttributes(new_fields)
                layer.updateFields()

            # Convert and add features
            batch = []
            for f in tile_feats:
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue

                nf = QgsFeature(layer.fields())
                nf.setGeometry(g)
                # set attributes by name (safe when fields differ)
                for fld in tile_fields:
                    nm = fld.name()
                    if nm in existing_fields:
                        try:
                            nf.setAttribute(nm, f[nm])
                        except Exception:
                            pass
                batch.append(nf)

            if batch:
                dp.addFeatures(batch)
                total_features += len(batch)

        progress.setValue(len(tiles))
        layer.updateExtents()

        if total_features == 0:
            raise RuntimeError("取得できた地物がありませんでした（範囲やネットワークを確認してください）。")

        QgsProject.instance().addMapLayer(layer)

        self.iface.messageBar().pushMessage(
            "GSI RDCL Downloader",
            f"完了: {total_features} 地物（失敗 {failed} タイル）を追加しました。",
            level=Qgis.Success,
            duration=8
        )

    def _fetch_text(self, url: str) -> str:
        req = QNetworkRequest(QUrl(url))
        bnr = QgsBlockingNetworkRequest()
        code = bnr.get(req, forceRefresh=False)
        if code != QgsBlockingNetworkRequest.NoError:
            QgsMessageLog.logMessage(
                f"Request failed ({code}): {url}  msg={bnr.errorMessage()}",
                "GSI RDCL Downloader",
                Qgis.Warning
            )
            return ""
        content = bnr.reply().content()
        try:
            return bytes(content).decode("utf-8")
        except Exception:
            # fallback
            try:
                return str(content, "utf-8")
            except Exception:
                return ""
